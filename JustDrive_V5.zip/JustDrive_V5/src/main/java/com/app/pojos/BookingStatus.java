package com.app.pojos;

public enum BookingStatus {
	PENDING,ONGOING,COMPLETED,CANCELED
}
